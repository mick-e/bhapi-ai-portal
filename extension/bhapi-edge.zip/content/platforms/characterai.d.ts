/**
 * Bhapi AI Safety Monitor — Character.ai Platform Adapter
 *
 * DOM selectors and helpers specific to character.ai and beta.character.ai.
 *
 * Character.ai is a companion chatbot platform where users form relationships
 * with AI characters. Bhapi monitors for emotional dependency patterns.
 */
import { PlatformSelectors } from "../../shared/types";
export declare const CHARACTERAI_SELECTORS: PlatformSelectors;
/**
 * Attempt to extract the character name from the page.
 */
export declare function getCharacterName(): string;
/**
 * Extract the current prompt text from the input area.
 */
export declare function getPromptText(): string;
/**
 * Count the number of character response messages visible.
 */
export declare function countResponses(): number;
//# sourceMappingURL=characterai.d.ts.map