/**
 * Bhapi AI Safety Monitor — Perplexity Platform Adapter
 *
 * DOM selectors and helpers specific to perplexity.ai.
 *
 * Perplexity is an AI-powered search engine that generates cited answers.
 * Bhapi monitors query patterns and session duration.
 */
import { PlatformSelectors } from "../../shared/types";
export declare const PERPLEXITY_SELECTORS: PlatformSelectors;
/**
 * Extract the current query/prompt text.
 */
export declare function getPromptText(): string;
/**
 * Count Perplexity answer blocks.
 */
export declare function countResponses(): number;
//# sourceMappingURL=perplexity.d.ts.map