/**
 * Bhapi AI Safety Monitor — Poe (Quora) Platform Adapter
 *
 * DOM selectors and helpers specific to poe.com.
 *
 * Poe is a multi-model AI chat platform by Quora, offering access to
 * ChatGPT, Claude, Gemini, and custom bots. Bhapi monitors all
 * conversations regardless of which underlying model is used.
 */
import { PlatformSelectors } from "../../shared/types";
export declare const POE_SELECTORS: PlatformSelectors;
/**
 * Extract the current prompt text.
 */
export declare function getPromptText(): string;
/**
 * Count Poe bot response messages.
 */
export declare function countResponses(): number;
//# sourceMappingURL=poe.d.ts.map