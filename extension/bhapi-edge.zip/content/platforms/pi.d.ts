/**
 * Bhapi AI Safety Monitor — Pi (Inflection AI) Platform Adapter
 *
 * DOM selectors and helpers specific to pi.ai.
 *
 * Pi is a personal AI assistant by Inflection AI, designed for empathetic
 * conversation. Bhapi monitors for emotional dependency patterns.
 */
import { PlatformSelectors } from "../../shared/types";
export declare const PI_SELECTORS: PlatformSelectors;
/**
 * Extract the current prompt text.
 */
export declare function getPromptText(): string;
/**
 * Count Pi response messages.
 */
export declare function countResponses(): number;
//# sourceMappingURL=pi.d.ts.map