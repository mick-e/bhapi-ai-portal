/**
 * Bhapi AI Safety Monitor — Replika Platform Adapter
 *
 * DOM selectors and helpers specific to web.replika.com.
 *
 * Replika is an AI companion app that can form deep emotional connections
 * with users. Bhapi monitors for emotional dependency patterns.
 */
import { PlatformSelectors } from "../../shared/types";
export declare const REPLIKA_SELECTORS: PlatformSelectors;
/**
 * Detect the current Replika relationship mode.
 * Replika offers Friend, Romantic Partner, and Mentor modes.
 */
export declare function getRelationshipMode(): string;
/**
 * Extract the current prompt text.
 */
export declare function getPromptText(): string;
/**
 * Count Replika response messages.
 */
export declare function countResponses(): number;
//# sourceMappingURL=replika.d.ts.map