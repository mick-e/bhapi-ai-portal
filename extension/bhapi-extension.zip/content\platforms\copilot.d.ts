/**
 * Bhapi AI Safety Monitor — Microsoft Copilot Platform Adapter
 *
 * DOM selectors and helpers specific to copilot.microsoft.com.
 *
 * NOTE: Microsoft Copilot's web UI uses a mix of React components and
 * Web Components (CIB — Conversational Intelligence Bot).  Selectors
 * target the outer shadow host boundaries where possible.
 */
import { PlatformSelectors } from "../../shared/types";
export declare const COPILOT_SELECTORS: PlatformSelectors;
/**
 * Attempt to extract the current prompt text from Copilot's input area.
 */
export declare function getPromptText(): string;
/**
 * Count the number of bot response messages currently visible.
 */
export declare function countResponses(): number;
//# sourceMappingURL=copilot.d.ts.map