/**
 * Bhapi AI Safety Monitor — Google Gemini Platform Adapter
 *
 * DOM selectors and helpers specific to gemini.google.com.
 *
 * NOTE: Google's Gemini UI uses Web Components and Shadow DOM extensively.
 * Some selectors target custom element tag names rather than class-based
 * selectors.  Selectors may need updates as Google iterates on the UI.
 */
import { PlatformSelectors } from "../../shared/types";
export declare const GEMINI_SELECTORS: PlatformSelectors;
/**
 * Attempt to extract the current prompt text from Gemini's input area.
 */
export declare function getPromptText(): string;
/**
 * Count the number of model response messages currently visible.
 */
export declare function countResponses(): number;
//# sourceMappingURL=gemini.d.ts.map