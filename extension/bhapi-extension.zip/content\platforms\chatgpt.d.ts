/**
 * Bhapi AI Safety Monitor — ChatGPT Platform Adapter
 *
 * DOM selectors and helpers specific to chatgpt.com.
 *
 * NOTE: These selectors are based on ChatGPT's DOM structure as of early 2026.
 * OpenAI frequently updates their frontend, so selectors may need periodic
 * maintenance.  The monitor falls back gracefully if selectors do not match.
 */
import { PlatformSelectors } from "../../shared/types";
export declare const CHATGPT_SELECTORS: PlatformSelectors;
/**
 * Attempt to extract the current prompt text from the input area.
 * Returns an empty string if the input cannot be found.
 */
export declare function getPromptText(): string;
/**
 * Count the number of assistant response messages currently visible.
 */
export declare function countResponses(): number;
//# sourceMappingURL=chatgpt.d.ts.map