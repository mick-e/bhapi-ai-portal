/**
 * Bhapi AI Safety Monitor — API Client
 *
 * Communicates with the Bhapi capture gateway.  All outbound requests
 * are HMAC-signed so the server can verify authenticity.
 *
 * Chrome: uses `chrome.storage.local` for configuration.
 * Firefox: the same API is available as `browser.storage.local`
 *          (or via the webextension-polyfill shim).
 */
import { CaptureEvent, ExtensionConfig } from "./types";
/**
 * Retrieve the extension configuration from chrome.storage.local.
 * Returns DEFAULT_CONFIG values for any keys that are missing.
 */
export declare function getConfig(): Promise<ExtensionConfig>;
/**
 * Persist a partial config update to chrome.storage.local.
 */
export declare function saveConfig(partial: Partial<ExtensionConfig>): Promise<void>;
interface ApiResponse<T = unknown> {
    ok: boolean;
    status: number;
    data: T | null;
    error: string | null;
}
/**
 * Send a capture event to the Bhapi gateway.
 *
 * POST /api/v1/capture/events
 */
export declare function sendEvent(event: CaptureEvent): Promise<ApiResponse>;
/**
 * Check the health of the capture gateway.
 *
 * GET /api/v1/capture/health
 */
export declare function checkStatus(): Promise<ApiResponse<{
    status: string;
}>>;
/**
 * Exchange a setup code for a signing secret and group/member IDs.
 *
 * POST /api/v1/capture/pair
 */
export declare function pairWithSetupCode(apiUrl: string, setupCode: string): Promise<ApiResponse<{
    groupId: string;
    memberId: string;
    signingSecret: string;
}>>;
export {};
//# sourceMappingURL=api.d.ts.map