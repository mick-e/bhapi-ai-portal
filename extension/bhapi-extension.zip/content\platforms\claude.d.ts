/**
 * Bhapi AI Safety Monitor — Anthropic Claude Platform Adapter
 *
 * DOM selectors and helpers specific to claude.ai.
 *
 * NOTE: Claude's web interface uses React with frequently changing
 * class names (often hashed/obfuscated).  We prefer data attributes,
 * ARIA labels, and structural selectors where possible.
 */
import { PlatformSelectors } from "../../shared/types";
export declare const CLAUDE_SELECTORS: PlatformSelectors;
/**
 * Attempt to extract the current prompt text from Claude's input area.
 */
export declare function getPromptText(): string;
/**
 * Count the number of assistant response messages currently visible.
 */
export declare function countResponses(): number;
//# sourceMappingURL=claude.d.ts.map