/**
 * Bhapi AI Safety Monitor — Popup Script
 *
 * Controls the popup UI that appears when the user clicks the extension
 * icon in the browser toolbar.
 *
 * Chrome: uses chrome.runtime.sendMessage and chrome.storage.local.
 * Firefox equivalent: browser.runtime.sendMessage and browser.storage.local.
 */
export {};
//# sourceMappingURL=popup.d.ts.map