/**
 * Bhapi AI Safety Monitor — HMAC-SHA256 Signing
 *
 * Uses the Web Crypto API (SubtleCrypto) which is available in both
 * service workers and content script contexts.
 *
 * Firefox equivalent: the same `crypto.subtle` API is available under
 * the standard Web Crypto interface — no `browser.*` shim needed.
 */
/**
 * Sign a payload string with an HMAC-SHA256 secret and return the
 * hex-encoded signature.
 *
 * @param payload - The string payload to sign (typically JSON).
 * @param secret  - The shared HMAC secret.
 * @returns A lowercase hex-encoded HMAC-SHA256 signature.
 */
export declare function signPayload(payload: string, secret: string): Promise<string>;
/**
 * Verify an HMAC-SHA256 signature for a payload.
 *
 * @param payload   - The original string payload.
 * @param secret    - The shared HMAC secret.
 * @param signature - The hex-encoded signature to verify.
 * @returns true if the signature is valid.
 */
export declare function verifySignature(payload: string, secret: string, signature: string): Promise<boolean>;
//# sourceMappingURL=crypto.d.ts.map