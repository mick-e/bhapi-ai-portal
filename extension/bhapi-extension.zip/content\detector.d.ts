/**
 * Bhapi AI Safety Monitor — AI Platform Detector
 *
 * Identifies which AI platform the user is currently on based on the
 * page URL.  Returns null for unsupported / unrecognised URLs.
 */
import { PlatformType } from "../shared/types";
/**
 * Detect which AI platform the given URL belongs to.
 *
 * @param url - A fully qualified URL string (e.g. window.location.href).
 * @returns The PlatformType if recognised, or null otherwise.
 */
export declare function detectPlatform(url: string): PlatformType | null;
//# sourceMappingURL=detector.d.ts.map