/**
 * Bhapi AI Safety Monitor — xAI Grok Platform Adapter
 *
 * DOM selectors and helpers specific to grok.com and x.com/i/grok.
 *
 * NOTE: Grok's web interface can be accessed both at grok.com (standalone)
 * and within the X/Twitter app at x.com/i/grok.  The DOM structure may
 * differ between these two entry points.
 */
import { PlatformSelectors } from "../../shared/types";
export declare const GROK_SELECTORS: PlatformSelectors;
/**
 * Attempt to extract the current prompt text from Grok's input area.
 */
export declare function getPromptText(): string;
/**
 * Count the number of bot response messages currently visible.
 */
export declare function countResponses(): number;
//# sourceMappingURL=grok.d.ts.map