/**
 * Bhapi AI Safety Monitor — Content Script (DOM Monitor)
 *
 * Injected into AI platform pages by the manifest's content_scripts config.
 * Responsibilities:
 *  1. Detect which AI platform we are on.
 *  2. Set up a MutationObserver to watch for prompt submissions and responses.
 *  3. Generate per-page session IDs.
 *  4. Forward capture events to the background service worker.
 *
 * This script is intentionally non-intrusive:
 *  - It does NOT modify the DOM.
 *  - It does NOT intercept network requests.
 *  - It only reads DOM state to detect usage events.
 *
 * Chrome: uses chrome.runtime.sendMessage.
 * Firefox equivalent: browser.runtime.sendMessage.
 */
export {};
//# sourceMappingURL=monitor.d.ts.map