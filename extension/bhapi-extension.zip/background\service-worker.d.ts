/**
 * Bhapi AI Safety Monitor — Background Service Worker
 *
 * Manifest V3 service worker that:
 *  1. Receives messages from content scripts and the popup.
 *  2. Forwards capture events to the Bhapi gateway API.
 *  3. Manages connection status and an offline event queue.
 *  4. Stores/retrieves configuration from chrome.storage.local.
 *
 * Firefox note: Firefox Manifest V3 uses `browser.*` APIs which are
 * largely compatible with `chrome.*`. A polyfill (webextension-polyfill)
 * can bridge any gaps.
 */
export {};
//# sourceMappingURL=service-worker.d.ts.map